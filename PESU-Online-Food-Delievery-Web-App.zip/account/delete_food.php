<?php
include 'includes/connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize input
    $foodId = filter_input(INPUT_POST, 'food_id', FILTER_SANITIZE_NUMBER_INT);

    // Perform the delete operation
    $sql = "DELETE FROM items WHERE id = :foodId";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':foodId', $foodId, PDO::PARAM_INT);

    if ($stmt->execute()) {
        echo 'Food item deleted successfully.';
    } else {
        echo 'Error deleting food item.';
    }
}
?>
